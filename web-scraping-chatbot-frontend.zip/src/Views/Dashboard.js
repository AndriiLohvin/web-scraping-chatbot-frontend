import ChatbotsTable from "../Components/ChatbotsTable";
export default function Dashboard(){
  return <ChatbotsTable />;
  
}